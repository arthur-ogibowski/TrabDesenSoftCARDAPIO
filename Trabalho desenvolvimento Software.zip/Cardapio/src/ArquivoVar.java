package restaurante.dominio;

public class ArquivoVar {

    private String nomePrato;
    private double precoPrato;
    private String nomeBebida;
    private double precoBebida;
    private String nomeVinho;
    private double precoVinho;

    public String getNomePrato() {
        return nomePrato;
    }
    public void setNomePrato(String nomePrato) {
        this.nomePrato = nomePrato;
    }
    public double getPrecoPrato() {
        return precoPrato;
    }
    public void setPrecoPrato(double precoPrato) {
        this.precoPrato = precoPrato;
    }

    public String getNomeBebida() {
        return nomeBebida;
    }
    public void setNomeBebida(String nomeBebida) {
        this.nomeBebida = nomeBebida;
    }
    public double getPrecoBebida() {
        return precoBebida;
    }
    public void setPrecoBebida(double precoBebida) {
        this.precoBebida = precoBebida;
    }

    public String getNomeVinho() {
        return nomeVinho;
    }
    public void setNomeVinho(String nomeVinho) {
        this.nomeVinho = nomeVinho;
    }
    public double getPrecoVinho() {
        return precoVinho;
    }
    public void setPrecoVinho(double precoVinho) {
        this.precoVinho = precoVinho;
    }
    private int codigoPrato;
    private int codigoBebida;
    private int codigoVinho;

    public String getNome() {
        return nomePrato;
    }
    public void setNome(String nome ) {
        this.nomePrato = nome;
    }
    public double getPreco() {
        return precoPrato;
    }
    public void setPreco(double preco) {
        this.precoPrato = preco;
    }
    public int getCodigoPrato() {
        return codigoPrato;
    }
    public void setCodigoPrato(int codigoPrato) {
        this.codigoPrato = codigoPrato;
    }
    public int getCodigoBebida() {
        return codigoBebida;
    }
    public void setCodigoBebida(int codigoBebida) {
        this.codigoBebida = codigoBebida;
    }
    public int getCodigoVinho() {
        return codigoVinho;
    }
    public void setCodigoVinho(int codigoVinho) {
        this.codigoVinho = codigoVinho;
    }










}